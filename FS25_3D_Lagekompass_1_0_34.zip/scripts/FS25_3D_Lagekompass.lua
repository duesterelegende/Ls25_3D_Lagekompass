--
-- FS25_3D_Lagekompass
-- Standalone vehicle attitude / compass HUD
-- Author: duestereLegende
-- Release 1.0.34
--

FS25_3D_Lagekompass = {}

local modName = g_currentModName or "FS25_3D_Lagekompass"
local modDirectory = g_currentModDirectory or ""

local SETTINGS_FOLDER_NAME = "FS25_3D_Lagekompass"
local SETTINGS_FILE_NAME = "settings.xml"

local UI_FALLBACK = {
    lk_section = "3D Attitude Compass",
    lk_show = "Show 3D Attitude Compass",
    lk_size = "HUD size",
    lk_rollIndicator = "Roll indicator",
    lk_arrows = "Arrows",
    lk_dots = "Dots",
    lk_hudBehavior = "HUD behavior",
    lk_hideWithHud = "Hide with HUD",
    lk_alwaysVisible = "Always visible",
    lk_positionHud = "Position HUD",
    lk_positionHint = "Left mouse button: drag   |   Right click: cancel"
}

-- Use the mod's own GIANTS i18n environment instead of reading g_languageShort
-- directly. The latter was not reliable in the settings screen and caused the
-- English fallback to be shown even while the game language was German.
local function getUiText(key)
    if g_i18n ~= nil then
        local modEnvironments = g_i18n.modEnvironments
        if modEnvironments ~= nil and modEnvironments[modName] ~= nil then
            local text = modEnvironments[modName]:getText(key)
            if text ~= nil and text ~= key then
                return text
            end
        end

        if g_i18n.getText ~= nil then
            local text = g_i18n:getText(key, modName)
            if text ~= nil and text ~= key then
                return text
            end
        end
    end

    return UI_FALLBACK[key] or key
end

local function getSettingsDirectory()
    return getUserProfileAppPath() .. "modSettings/" .. SETTINGS_FOLDER_NAME .. "/"
end

local function getSettingsFilename()
    return getSettingsDirectory() .. SETTINGS_FILE_NAME
end

local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

local function normalize360(a)
    a = a % 360
    if a < 0 then a = a + 360 end
    return a
end

local function normalize180(a)
    a = normalize360(a)
    if a > 180 then a = a - 360 end
    return a
end

local function angleDelta(target, current)
    return normalize180(target - current)
end

local function lerpAngle(current, target, alpha)
    return normalize360(current + angleDelta(target, current) * alpha)
end

local function headingFromVehicle(vehicle)
    if vehicle == nil or vehicle.rootNode == nil then return nil end
    local dx, _, dz = localDirectionToWorld(vehicle.rootNode, 0, 0, 1)
    local yaw = math.deg(MathUtil.getYRotationFromDirection(dx, dz))
    return normalize360(180 - yaw)
end

local function attitudeFromVehicle(vehicle)
    if vehicle == nil or vehicle.rootNode == nil then return nil, nil end

    -- Actual geometric pitch from the vehicle forward vector versus the world horizon.
    local fx, fy, fz = localDirectionToWorld(vehicle.rootNode, 0, 0, 1)
    local horizontalForward = math.sqrt(fx * fx + fz * fz)
    local pitch = math.deg(math.atan2(fy, horizontalForward))

    -- Roll from right/up vectors. atan2 removes most pitch/yaw cross-coupling.
    local _, ry, _ = localDirectionToWorld(vehicle.rootNode, 1, 0, 0)
    local _, uy, _ = localDirectionToWorld(vehicle.rootNode, 0, 1, 0)
    local roll = -math.deg(math.atan2(ry, uy))

    return pitch, roll
end

local function cardinalFor(angle)
    local idx = math.floor((normalize360(angle) + 22.5) / 45) % 8
    local names = { "N", "NE", "E", "SE", "S", "SW", "W", "NW" }
    return names[idx + 1]
end

local function colorForScale(absAngle)
    if absAngle >= 40 then
        return 1.00, 0.10, 0.12, 1.0
    elseif absAngle >= 30 then
        return 0.98, 0.52, 0.02, 1.0
    elseif absAngle >= 20 then
        return 0.92, 0.82, 0.02, 1.0
    else
        return 0.20, 1.00, 0.15, 1.0
    end
end

function FS25_3D_Lagekompass:loadSettings()
    self.hudEnabled = true
    self.hudScale = 1.0
    self.hudCenterX = 0.855
    self.hudCenterY = 0.665
    self.rollDisplayMode = 1 -- 1 = arrows, 2 = dots
    self.hudVisibilityMode = 1 -- 1 = follow game HUD, 2 = always visible
    self.positionEditMode = false
    self.isDraggingHud = false
    self.settingsUiInjected = false

    local filename = getSettingsFilename()
    if fileExists(filename) then
        local xml = loadXMLFile("lagekompassSettings", filename)
        if xml ~= 0 then
            local enabled = getXMLBool(xml, "lagekompass#enabled")
            local scale = getXMLFloat(xml, "lagekompass#scale")
            local posX = getXMLFloat(xml, "lagekompass#posX")
            local posY = getXMLFloat(xml, "lagekompass#posY")
            local rollDisplayMode = getXMLInt(xml, "lagekompass#rollDisplayMode")
            local hudVisibilityMode = getXMLInt(xml, "lagekompass#hudVisibilityMode")

            if enabled ~= nil then self.hudEnabled = enabled end
            if scale ~= nil then self.hudScale = clamp(scale, 0.50, 1.50) end
            if posX ~= nil then self.hudCenterX = clamp(posX, 0.05, 0.95) end
            if posY ~= nil then self.hudCenterY = clamp(posY, 0.05, 0.95) end
            if rollDisplayMode ~= nil then self.rollDisplayMode = clamp(math.floor(rollDisplayMode + 0.5), 1, 2) end
            if hudVisibilityMode ~= nil then self.hudVisibilityMode = clamp(math.floor(hudVisibilityMode + 0.5), 1, 2) end
            delete(xml)
        end
    end
end

function FS25_3D_Lagekompass:saveSettings()
    local dir = getSettingsDirectory()
    createFolder(dir)

    local filename = getSettingsFilename()
    local xml = createXMLFile("lagekompassSettings", filename, "lagekompass")
    if xml ~= 0 then
        setXMLBool(xml, "lagekompass#enabled", self.hudEnabled == true)
        setXMLFloat(xml, "lagekompass#scale", self.hudScale or 1.0)
        setXMLFloat(xml, "lagekompass#posX", self.hudCenterX or 0.855)
        setXMLFloat(xml, "lagekompass#posY", self.hudCenterY or 0.665)
        setXMLInt(xml, "lagekompass#rollDisplayMode", self.rollDisplayMode or 1)
        setXMLInt(xml, "lagekompass#hudVisibilityMode", self.hudVisibilityMode or 1)
        saveXMLFile(xml)
        delete(xml)
    end
end

function FS25_3D_Lagekompass:rebuildHud()
    self:deleteOverlays()
    self:ensureHud()
end

function FS25_3D_Lagekompass:setHudEnabled(enabled)
    self.hudEnabled = enabled == true
    if not self.hudEnabled and self.positionEditMode then
        self:stopPositionEdit(false)
    end
    self:saveSettings()
end

function FS25_3D_Lagekompass:setHudScale(scale)
    self.hudScale = clamp(scale or 1.0, 0.50, 1.50)
    self:saveSettings()
    self:rebuildHud()
end

function FS25_3D_Lagekompass:setRollDisplayMode(mode)
    self.rollDisplayMode = clamp(math.floor((mode or 1) + 0.5), 1, 2)
    self:saveSettings()
end

function FS25_3D_Lagekompass:setHudVisibilityMode(mode)
    self.hudVisibilityMode = clamp(math.floor((mode or 1) + 0.5), 1, 2)
    self:saveSettings()
end

function FS25_3D_Lagekompass:clampHudCenter(x, y)
    if self.hudW == nil or self.hudH == nil then
        return clamp(x, 0.05, 0.95), clamp(y, 0.05, 0.95)
    end

    local marginX = self.hudW * 0.62
    local marginY = self.hudH * 0.62
    return clamp(x, marginX, 1 - marginX), clamp(y, marginY, 1 - marginY)
end

function FS25_3D_Lagekompass:startPositionEdit()
    if self.hudEnabled == false then
        self.hudEnabled = true
    end

    self.positionEditMode = true
    self.isDraggingHud = false
    if g_inputBinding ~= nil then
        g_inputBinding:setShowMouseCursor(true)
    end
    self:saveSettings()
end

function FS25_3D_Lagekompass:stopPositionEdit(savePosition)
    self.positionEditMode = false
    self.isDraggingHud = false
    self.dragOffsetX = nil
    self.dragOffsetY = nil

    if g_inputBinding ~= nil and (g_gui == nil or g_gui.currentGui == nil) then
        g_inputBinding:setShowMouseCursor(false)
    end

    if savePosition ~= false then
        self:saveSettings()
    end

    self:refreshSettingsUi()
end

function FS25_3D_Lagekompass:mouseEvent(posX, posY, isDown, isUp, button)
    if not self.positionEditMode or not self.hudEnabled then
        return false
    end

    -- Let the normal GUI own the mouse while a menu/dialog is open. The editor
    -- becomes active immediately after returning to the game.
    if g_gui ~= nil and g_gui.currentGui ~= nil then
        return false
    end

    local leftButton = Input ~= nil and Input.MOUSE_BUTTON_LEFT or 1
    local rightButton = Input ~= nil and Input.MOUSE_BUTTON_RIGHT or 3

    if button == rightButton and isDown then
        self:stopPositionEdit(false)
        return true
    end

    if button == leftButton and isDown then
        local inside = posX >= self.hudX and posX <= self.hudX + self.hudW and
                       posY >= self.hudY and posY <= self.hudY + self.hudH
        if inside then
            self.isDraggingHud = true
            self.dragOffsetX = self.centerX - posX
            self.dragOffsetY = self.centerY - posY
            return true
        end
    end

    if self.isDraggingHud then
        local newX = posX + (self.dragOffsetX or 0)
        local newY = posY + (self.dragOffsetY or 0)
        newX, newY = self:clampHudCenter(newX, newY)
        self.hudCenterX = newX
        self.hudCenterY = newY
        self.centerX = newX
        self.centerY = newY
        self.hudX = self.centerX - self.hudW * 0.5
        self.hudY = self.centerY - self.hudH * 0.5

        if isUp and button == leftButton then
            self.isDraggingHud = false
            self:saveSettings()
            self:stopPositionEdit(true)
        end
        return true
    end

    return false
end

local function findSettingsTemplate(layout, kind)
    if layout == nil or layout.elements == nil then return nil end
    for _, row in ipairs(layout.elements) do
        if row.elements ~= nil and #row.elements >= 2 then
            local first = row.elements[1]
            if first ~= nil and first.id ~= nil then
                if kind == "binary" and (string.find(first.id, "^check") or string.find(first.id, "Check")) then
                    return row
                elseif kind == "multi" and string.find(first.id, "^multi") then
                    return row
                end
            end
        end
    end
    return nil
end

local function addSettingsSection(layout, text)
    if layout == nil or layout.elements == nil then return nil end
    for _, element in ipairs(layout.elements) do
        if element.name == "sectionHeader" and element.clone ~= nil then
            local section = element:clone(layout)
            section.id = nil
            if section.setText ~= nil then section:setText(text) end
            layout:addElement(section)
            return section
        end
    end
    return nil
end

local function addBinarySetting(layout, label, state, callback)
    local template = findSettingsTemplate(layout, "binary")
    if template == nil then return nil end

    local row = template:clone(layout)
    row.id = nil
    local option = row.elements[1]
    local textElement = row.elements[2]
    option.id = nil
    option.target = nil
    if textElement ~= nil then textElement.id = nil end

    if textElement ~= nil and textElement.setText ~= nil then textElement:setText(label) end
    option.onClickCallback = function(newState, element)
        callback(newState == 2)
    end

    layout:addElement(row)
    if option.setState ~= nil then option:setState(1) end
    if state then
        if option.setIsChecked ~= nil then option:setIsChecked(true)
        elseif option.setState ~= nil then option:setState(2) end
    end
    return option
end

local function addMultiSetting(layout, label, choices, state, callback)
    local template = findSettingsTemplate(layout, "multi")
    if template == nil then return nil end

    local row = template:clone(layout)
    row.id = nil
    local option = row.elements[1]
    local textElement = row.elements[2]
    option.id = nil
    option.target = nil
    if textElement ~= nil then textElement.id = nil end

    if textElement ~= nil and textElement.setText ~= nil then textElement:setText(label) end
    if option.setTexts ~= nil then option:setTexts(choices) end
    if option.setState ~= nil then option:setState(state) end
    option.onClickCallback = function(newState, element)
        callback(newState)
    end

    layout:addElement(row)
    return option
end

function FS25_3D_Lagekompass:injectSettingsUi(frame)
    if frame == nil or frame.generalSettingsLayout == nil then return end
    local layout = frame.generalSettingsLayout

    if not self.settingsUiInjected then
        local ok, err = pcall(function()
            addSettingsSection(layout, getUiText("lk_section"))

            self.settingsEnabledOption = addBinarySetting(
                layout,
                getUiText("lk_show"),
                self.hudEnabled,
                function(value)
                    self:setHudEnabled(value)
                end)

            local sizeChoices = {}
            for percent = 50, 150, 5 do
                table.insert(sizeChoices, tostring(percent) .. "%")
            end
            local sizeIndex = math.floor(((self.hudScale or 1.0) * 100 - 50) / 5 + 0.5) + 1
            sizeIndex = clamp(sizeIndex, 1, #sizeChoices)
            self.settingsScaleOption = addMultiSetting(
                layout,
                getUiText("lk_size"),
                sizeChoices,
                sizeIndex,
                function(index)
                    self:setHudScale((50 + (index - 1) * 5) / 100)
                end)

            self.settingsRollDisplayOption = addMultiSetting(
                layout,
                getUiText("lk_rollIndicator"),
                { getUiText("lk_arrows"), getUiText("lk_dots") },
                self.rollDisplayMode or 1,
                function(index)
                    self:setRollDisplayMode(index)
                end)

            self.settingsHudVisibilityOption = addMultiSetting(
                layout,
                getUiText("lk_hudBehavior"),
                { getUiText("lk_hideWithHud"), getUiText("lk_alwaysVisible") },
                self.hudVisibilityMode or 1,
                function(index)
                    self:setHudVisibilityMode(index)
                end)

            self.settingsPositionOption = addBinarySetting(
                layout,
                getUiText("lk_positionHud"),
                self.positionEditMode,
                function(value)
                    if value then self:startPositionEdit() else self:stopPositionEdit(true) end
                end)

            self.settingsUiInjected = true
            layout:invalidateLayout()
        end)

        if not ok then
            print("[" .. modName .. "] WARNING: settings UI injection failed: " .. tostring(err))
            return
        end
    end

    self:refreshSettingsUi()
end

function FS25_3D_Lagekompass:refreshSettingsUi()
    if self.settingsEnabledOption ~= nil then
        if self.settingsEnabledOption.setIsChecked ~= nil then
            self.settingsEnabledOption:setIsChecked(self.hudEnabled)
        elseif self.settingsEnabledOption.setState ~= nil then
            self.settingsEnabledOption:setState(self.hudEnabled and 2 or 1)
        end
    end

    if self.settingsScaleOption ~= nil and self.settingsScaleOption.setState ~= nil then
        local index = math.floor(((self.hudScale or 1.0) * 100 - 50) / 5 + 0.5) + 1
        self.settingsScaleOption:setState(clamp(index, 1, 21))
    end

    if self.settingsRollDisplayOption ~= nil and self.settingsRollDisplayOption.setState ~= nil then
        self.settingsRollDisplayOption:setState(clamp(self.rollDisplayMode or 1, 1, 2))
    end

    if self.settingsHudVisibilityOption ~= nil and self.settingsHudVisibilityOption.setState ~= nil then
        self.settingsHudVisibilityOption:setState(clamp(self.hudVisibilityMode or 1, 1, 2))
    end

    if self.settingsPositionOption ~= nil then
        if self.settingsPositionOption.setIsChecked ~= nil then
            self.settingsPositionOption:setIsChecked(self.positionEditMode)
        elseif self.settingsPositionOption.setState ~= nil then
            self.settingsPositionOption:setState(self.positionEditMode and 2 or 1)
        end
    end
end

function FS25_3D_Lagekompass:drawPositionEditHint()
    if not self.positionEditMode then return end
    local speedMeter = g_currentMission.hud.speedMeter
    local uiScale = self.hudScale or 1.0
    local size = speedMeter:scalePixelToScreenHeight(10 * uiScale)
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_MIDDLE)
    setTextBold(true)
    setTextColor(1, 1, 1, 1)
    renderText(self.centerX, self.hudY + self.hudH + speedMeter:scalePixelToScreenHeight(13 * uiScale), size,
        getUiText("lk_positionHint"))
end

function FS25_3D_Lagekompass:loadMap()
    self:loadSettings()

    self.sphereFilename = Utils.getFilename("resources/sphere.png", modDirectory)
    self.outerScaleFilename = Utils.getFilename("resources/outerScaleTicks.png", modDirectory)
    self.rollArrowsFilename = Utils.getFilename("resources/rollArrows.png", modDirectory)
    self.pitchDotFilename = Utils.getFilename("resources/pitchDot.png", modDirectory)
    self.pixelFilename = Utils.getFilename("resources/pixel.png", modDirectory)

    self.vehicle = nil
    self.heading = 0
    self.pitch = 0
    self.roll = 0
    self.lastVehicle = nil
    self.initialized = false

    self.pitchDeadzone = 0.05
    self.rollDeadzone = 0.08
    
    print("--> loaded " .. modName .. " 1.0.34 <--")
end

function FS25_3D_Lagekompass:deleteOverlays()
    if self.sphereOverlay ~= nil then self.sphereOverlay:delete(); self.sphereOverlay = nil end
    if self.outerScaleOverlay ~= nil then self.outerScaleOverlay:delete(); self.outerScaleOverlay = nil end
    if self.rollArrowsOverlay ~= nil then self.rollArrowsOverlay:delete(); self.rollArrowsOverlay = nil end
    if self.rollDotRightOverlay ~= nil then self.rollDotRightOverlay:delete(); self.rollDotRightOverlay = nil end
    if self.rollDotLeftOverlay ~= nil then self.rollDotLeftOverlay:delete(); self.rollDotLeftOverlay = nil end
    if self.pitchMarkerUpOverlay ~= nil then self.pitchMarkerUpOverlay:delete(); self.pitchMarkerUpOverlay = nil end
    if self.pitchMarkerDownOverlay ~= nil then self.pitchMarkerDownOverlay:delete(); self.pitchMarkerDownOverlay = nil end
    if self.pixelOverlay ~= nil then self.pixelOverlay:delete(); self.pixelOverlay = nil end
    if self.tickOverlays ~= nil then
        for _, overlay in ipairs(self.tickOverlays) do
            if overlay ~= nil then overlay:delete() end
        end
    end
    self.tickOverlays = nil
    self.initialized = false
end

function FS25_3D_Lagekompass:unloadMap()
    self:saveSettings()
    if self.positionEditMode and g_inputBinding ~= nil then g_inputBinding:setShowMouseCursor(false) end
    self:deleteOverlays()
    print("--> unloaded " .. modName .. " <--")
end

function FS25_3D_Lagekompass:ensureHud()
    if self.initialized then return true end
    if g_currentMission == nil or g_currentMission.hud == nil or g_currentMission.hud.speedMeter == nil then
        return false
    end

    local speedMeter = g_currentMission.hud.speedMeter
    self.baseHudPxNominal = 230 * 1.30
    self.baseHudPx = self.baseHudPxNominal * (self.hudScale or 1.0)

    local w, h = speedMeter:scalePixelToScreenVector({ self.baseHudPx, self.baseHudPx })
    local pitchMarkerW, pitchMarkerH = speedMeter:scalePixelToScreenVector({ 14.45 * (self.hudScale or 1.0), 14.45 * (self.hudScale or 1.0) })
    local rollMarkerW, rollMarkerH = speedMeter:scalePixelToScreenVector({ 14.45 * (self.hudScale or 1.0), 14.45 * (self.hudScale or 1.0) })

    local centerX = self.hudCenterX or 0.855
    local centerY = self.hudCenterY or 0.665
    local x = centerX - w * 0.5
    local y = centerY - h * 0.5

    self.hudX = x
    self.hudY = y
    self.hudW = w
    self.hudH = h
    self.centerX = centerX
    self.centerY = centerY

    -- The sphere image was normalised to an exact circle: 607px radius in a 1254px source.
    self.sphereRadiusNorm = 607 / 1254
    self.bandHalfNorm = 0.076
    self.pitchPoleNorm = 0.435

    -- The lower pitch scale visually starts a little too high relative to the
    -- lower edge of the black compass band. Move the complete lower scale
    -- (0 point, ticks, axis and lower pitch marker start) down by 5 HUD pixels.
    local _, lowerPitchOffsetY = speedMeter:scalePixelToScreenVector({ 0, 5 * (self.hudScale or 1.0) })
    self.lowerPitchOffsetY = lowerPitchOffsetY

    self.pitchMarkerW = pitchMarkerW
    self.pitchMarkerH = pitchMarkerH
    self.rollMarkerW = rollMarkerW
    self.rollMarkerH = rollMarkerH

    self.sphereOverlay = Overlay.new(self.sphereFilename, x, y, w, h)
    self.outerScaleFactor = 1.10
    local outerW = w * self.outerScaleFactor
    local outerH = h * self.outerScaleFactor
    self.outerScaleOverlay = Overlay.new(self.outerScaleFilename, centerX - outerW * 0.5, centerY - outerH * 0.5, outerW, outerH)
    -- Version-2 principle: both roll arrows are one overlay and therefore always move
    -- perfectly opposite around one common centre pivot. No visible connecting line.
    self.rollArrowsOverlay = Overlay.new(self.rollArrowsFilename, x, y, w, h)
    self.rollDotRightOverlay = Overlay.new(self.pitchDotFilename, 0, 0, rollMarkerW, rollMarkerH)
    self.rollDotLeftOverlay = Overlay.new(self.pitchDotFilename, 0, 0, rollMarkerW, rollMarkerH)

    self.pitchMarkerUpOverlay = Overlay.new(self.pitchDotFilename, 0, 0, pitchMarkerW, pitchMarkerH)
    self.pitchMarkerDownOverlay = Overlay.new(self.pitchDotFilename, 0, 0, pitchMarkerW, pitchMarkerH)
    self.pixelOverlay = Overlay.new(self.pixelFilename, 0, 0, 1, 1)

    self.tickOverlays = {}
    for i = 1, 180 do
        self.tickOverlays[i] = Overlay.new(self.pixelFilename, 0, 0, 0, 0)
    end

    self.initialized = true
    return true
end

function FS25_3D_Lagekompass:update(dt)
    if g_currentMission == nil then return end

    local vehicle = self.vehicle
    if vehicle == nil then
        vehicle = g_currentMission.controlledVehicle
    end
    if vehicle == nil and g_localPlayer ~= nil and type(g_localPlayer.getCurrentVehicle) == "function" then
        vehicle = g_localPlayer:getCurrentVehicle()
    end
    if vehicle == nil or vehicle.rootNode == nil then
        self.vehicle = nil
        return
    end

    local heading = headingFromVehicle(vehicle)
    local pitch, roll = attitudeFromVehicle(vehicle)
    if heading == nil or pitch == nil or roll == nil then
        self.vehicle = nil
        return
    end

    self.vehicle = vehicle

    if math.abs(pitch) < self.pitchDeadzone then pitch = 0 end
    if math.abs(roll) < self.rollDeadzone then roll = 0 end

    if pitch > 0.20 then
        elseif pitch < -0.20 then
        self.pitchSign = -1
    end

    if self.lastVehicle ~= vehicle then
        self.heading = heading
        self.pitch = pitch
        self.roll = roll
        self.lastVehicle = vehicle
    else
        -- Only light damping: fast enough to follow the actual vehicle angle closely,
        -- but suppressing physics micro-jitter.
        local headingAlpha = clamp((dt or 16) / 70, 0.12, 0.45)
        local attitudeAlpha = clamp((dt or 16) / 55, 0.16, 0.45)

        self.heading = lerpAngle(self.heading, heading, headingAlpha)
        self.pitch = self.pitch + (pitch - self.pitch) * attitudeAlpha
        local rollDiff = normalize180(roll - self.roll)
        self.roll = normalize180(self.roll + rollDiff * attitudeAlpha)
    end
end

function FS25_3D_Lagekompass:pointOnHudCircle(angleDeg, radiusNorm)
    local a = math.rad(angleDeg)
    return self.centerX + self.hudW * radiusNorm * math.cos(a),
           self.centerY + self.hudH * radiusNorm * math.sin(a)
end

function FS25_3D_Lagekompass:drawDot(x, y, sizePx, r, g, b, a)
    local speedMeter = g_currentMission.hud.speedMeter
    local uiScale = self.hudScale or 1.0
    local sw, sh = speedMeter:scalePixelToScreenVector({ sizePx * uiScale, sizePx * uiScale })
    self.pixelOverlay:setPosition(x - sw * 0.5, y - sh * 0.5)
    self.pixelOverlay:setDimension(sw, sh)
    self.pixelOverlay:setRotation(0, 0, 0)
    self.pixelOverlay:setColor(r, g, b, a)
    self.pixelOverlay:render()
end

function FS25_3D_Lagekompass:drawRadialTick(angleDeg, startNorm, endNorm, major, r, g, b, a)
    local steps = major and 7 or 4
    local dotPx = major and 2.1 or 1.65
    for i = 0, steps - 1 do
        local t = (steps == 1) and 0 or (i / (steps - 1))
        local radius = startNorm + (endNorm - startNorm) * t
        local x, y = self:pointOnHudCircle(angleDeg, radius)
        self:drawDot(x, y, dotPx, r, g, b, a)
    end
end

function FS25_3D_Lagekompass:drawOuterScale()
    local speedMeter = g_currentMission.hud.speedMeter
    local uiScale = self.hudScale or 1.0
    local numberSize = speedMeter:scalePixelToScreenHeight(9.5 * uiScale)
    local radialBase = self.baseHudPxNominal or (230 * 1.30)
    local labelRadius = self.sphereRadiusNorm + (21.0 / radialBase)

    -- The tick marks themselves are now a high-resolution transparent overlay.
    -- Only the labels stay dynamic, so resizing no longer turns diagonal ticks
    -- into a chain of square dots / jagged short segments.
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_MIDDLE)
    setTextBold(true)

    for angle = -90, 90, 10 do
        local absAngle = math.abs(angle)
        local cr, cg, cb, ca = colorForScale(absAngle)
        local label = angle == 0 and "0" or string.format("%+d", angle)
        local tx, ty = self:pointOnHudCircle(angle, labelRadius)
        setTextColor(cr, cg, cb, 1)
        renderText(tx, ty, numberSize, label)

        if math.abs(angle) < 90 then
            local ltx, lty = self:pointOnHudCircle(180 - angle, labelRadius)
            renderText(ltx, lty, numberSize, label)
        end
    end
end

function FS25_3D_Lagekompass:drawPitchScale()
    local speedMeter = g_currentMission.hud.speedMeter
    local uiScale = self.hudScale or 1.0
    local majorW, tickH = speedMeter:scalePixelToScreenVector({ 30 * uiScale, 2 * uiScale })
    local minorW, _ = speedMeter:scalePixelToScreenVector({ 18 * uiScale, 2 * uiScale })
    local axisW, _ = speedMeter:scalePixelToScreenVector({ 1.5 * uiScale, 1 * uiScale })
    local numberSize = speedMeter:scalePixelToScreenHeight(9.5 * uiScale)

    local upperEdge = self.centerY + self.hudH * self.bandHalfNorm
    local lowerEdge = self.centerY - self.hudH * self.bandHalfNorm - self.lowerPitchOffsetY
    local upperPole = self.centerY + self.hudH * self.pitchPoleNorm
    local lowerPole = self.centerY - self.hudH * self.pitchPoleNorm - self.lowerPitchOffsetY
    local upperSpan = upperPole - upperEdge
    local lowerSpan = lowerEdge - lowerPole

    -- centre axes only in the two blue hemispheres
    self.pixelOverlay:setPosition(self.centerX - axisW * 0.5, upperEdge)
    self.pixelOverlay:setDimension(axisW, upperSpan)
    self.pixelOverlay:setRotation(0, 0, 0)
    self.pixelOverlay:setColor(0.92, 0.95, 0.98, 0.78)
    self.pixelOverlay:render()

    self.pixelOverlay:setPosition(self.centerX - axisW * 0.5, lowerPole)
    self.pixelOverlay:setDimension(axisW, lowerSpan)
    self.pixelOverlay:render()

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_MIDDLE)
    setTextBold(true)
    setTextColor(0.95, 0.97, 1.0, 1)

    for a = 5, 50, 5 do
        local s = math.sin(math.rad(a))
        local yPos = upperEdge + upperSpan * s
        local yNeg = lowerEdge - lowerSpan * s
        local major = (a % 10) == 0
        local tw = major and majorW or minorW
        local alpha = major and 0.95 or 0.75

        self.pixelOverlay:setPosition(self.centerX - tw * 0.5, yPos - tickH * 0.5)
        self.pixelOverlay:setDimension(tw, tickH)
        self.pixelOverlay:setRotation(0, 0, 0)
        self.pixelOverlay:setColor(0.92, 0.95, 0.98, alpha)
        self.pixelOverlay:render()

        self.pixelOverlay:setPosition(self.centerX - tw * 0.5, yNeg - tickH * 0.5)
        self.pixelOverlay:render()

        if major then
            renderText(self.centerX + tw * 0.67, yPos, numberSize, tostring(a))
            renderText(self.centerX + tw * 0.67, yNeg, numberSize, "-" .. tostring(a))
        end
    end
end

function FS25_3D_Lagekompass:drawPitchMarkers()
    local pitch = clamp(self.pitch, -90, 90)

    local upperEdge = self.centerY + self.hudH * self.bandHalfNorm
    local lowerEdge = self.centerY - self.hudH * self.bandHalfNorm - self.lowerPitchOffsetY
    local upperPole = self.centerY + self.hudH * self.pitchPoleNorm
    local lowerPole = self.centerY - self.hudH * self.pitchPoleNorm - self.lowerPitchOffsetY
    local upperSpan = upperPole - upperEdge
    local lowerSpan = lowerEdge - lowerPole

    -- Exactly one pitch marker is visible at a time:
    -- positive pitch = upper dot, negative pitch = lower dot.
    -- Around zero no marker is rendered, avoiding a visual jump between both scales.
    local markerDeadzone = self.pitchDeadzone
    if pitch > markerDeadzone then
        local upY = upperEdge + upperSpan * math.sin(math.rad(pitch))
        local r, g, b, _ = colorForScale(pitch)
        self.pitchMarkerUpOverlay:setPosition(self.centerX - self.pitchMarkerW * 0.5, upY - self.pitchMarkerH * 0.5)
        self.pitchMarkerUpOverlay:setDimension(self.pitchMarkerW, self.pitchMarkerH)
        self.pitchMarkerUpOverlay:setRotation(0, self.pitchMarkerW * 0.5, self.pitchMarkerH * 0.5)
        self.pitchMarkerUpOverlay:setColor(r, g, b, 1)
        self.pitchMarkerUpOverlay:render()
    elseif pitch < -markerDeadzone then
        local pitchDown = -pitch
        local downY = lowerEdge - lowerSpan * math.sin(math.rad(pitchDown))
        local r, g, b, _ = colorForScale(pitchDown)
        self.pitchMarkerDownOverlay:setPosition(self.centerX - self.pitchMarkerW * 0.5, downY - self.pitchMarkerH * 0.5)
        self.pitchMarkerDownOverlay:setDimension(self.pitchMarkerW, self.pitchMarkerH)
        self.pitchMarkerDownOverlay:setRotation(0, self.pitchMarkerW * 0.5, self.pitchMarkerH * 0.5)
        self.pitchMarkerDownOverlay:setColor(r, g, b, 1)
        self.pitchMarkerDownOverlay:render()
    end
end

function FS25_3D_Lagekompass:drawRollIndicator()
    local roll = clamp(self.roll, -90, 90)
    local r, g, b, _ = colorForScale(math.abs(roll))

    if (self.rollDisplayMode or 1) == 2 then
        -- Dot mode: the two markers use exactly the same circular path as the
        -- arrow pair. Their centres sit directly on the sphere circumference.
        local rightX, rightY = self:pointOnHudCircle(-roll, self.sphereRadiusNorm)
        local leftX, leftY = self:pointOnHudCircle(180 - roll, self.sphereRadiusNorm)

        self.rollDotRightOverlay:setPosition(rightX - self.rollMarkerW * 0.5, rightY - self.rollMarkerH * 0.5)
        self.rollDotRightOverlay:setDimension(self.rollMarkerW, self.rollMarkerH)
        self.rollDotRightOverlay:setRotation(0, self.rollMarkerW * 0.5, self.rollMarkerH * 0.5)
        self.rollDotRightOverlay:setColor(r, g, b, 1)
        self.rollDotRightOverlay:render()

        self.rollDotLeftOverlay:setPosition(leftX - self.rollMarkerW * 0.5, leftY - self.rollMarkerH * 0.5)
        self.rollDotLeftOverlay:setDimension(self.rollMarkerW, self.rollMarkerH)
        self.rollDotLeftOverlay:setRotation(0, self.rollMarkerW * 0.5, self.rollMarkerH * 0.5)
        self.rollDotLeftOverlay:setColor(r, g, b, 1)
        self.rollDotLeftOverlay:render()
    else
        -- Existing arrow mode from the confirmed base remains unchanged.
        self.rollArrowsOverlay:setPosition(self.hudX, self.hudY)
        self.rollArrowsOverlay:setDimension(self.hudW, self.hudH)
        self.rollArrowsOverlay:setRotation(-math.rad(roll), self.hudW * 0.5, self.hudH * 0.5)
        self.rollArrowsOverlay:setColor(r, g, b, 1)
        self.rollArrowsOverlay:render()
    end
end

function FS25_3D_Lagekompass:drawCompassCenterLine()
    local speedMeter = g_currentMission.hud.speedMeter
    local uiScale = self.hudScale or 1.0
    local lineW, _ = speedMeter:scalePixelToScreenVector({ 1.4 * uiScale, 1 * uiScale })
    local bandTopY = self.centerY + self.hudH * self.bandHalfNorm
    local bandBottomY = self.centerY - self.hudH * self.bandHalfNorm
    local lineH = bandTopY - bandBottomY

    self.pixelOverlay:setPosition(self.centerX - lineW * 0.5, bandBottomY)
    self.pixelOverlay:setDimension(lineW, lineH)
    self.pixelOverlay:setRotation(0, 0, 0)
    self.pixelOverlay:setColor(0.92, 0.12, 0.12, 0.90)
    self.pixelOverlay:render()
end

function FS25_3D_Lagekompass:drawCompassTape()
    local speedMeter = g_currentMission.hud.speedMeter
    local heading = self.heading
    local spanX = self.hudW * 0.402
    local bandTopY = self.centerY + self.hudH * self.bandHalfNorm
    local bandBottomY = self.centerY - self.hudH * self.bandHalfNorm

    local uiScale = self.hudScale or 1.0
    local textSizeCardinal = speedMeter:scalePixelToScreenHeight(11 * uiScale)
    local textSizeDegree = speedMeter:scalePixelToScreenHeight(8 * uiScale)
    local tickMajorW, tickMajorH = speedMeter:scalePixelToScreenVector({ 2 * uiScale, 9 * uiScale })
    local tickMinorW, tickMinorH = speedMeter:scalePixelToScreenVector({ 1 * uiScale, 6 * uiScale })

    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_MIDDLE)
    setTextBold(true)

    local tickIndex = 1
    local startMark = math.floor((heading - 88) / 5) * 5
    local endMark = heading + 88
    local mark = startMark

    while mark <= endMark and tickIndex + 1 <= #self.tickOverlays do
        local wrapped = normalize360(mark)
        local delta = normalize180(wrapped - heading)
        if math.abs(delta) <= 84 then
            local t = delta / 84
            local x = self.centerX + spanX * math.sin(t * math.pi * 0.5)
            local edge = math.abs(t)
            local curve = self.hudH * 0.010 * edge * edge
            local major = (math.floor(wrapped + 0.5) % 45) == 0
            local mid = (math.floor(wrapped + 0.5) % 15) == 0
            local tw = major and tickMajorW or tickMinorW
            local th = major and tickMajorH or tickMinorH
            if mid and not major then th = th * 1.18 end

            local topTick = self.tickOverlays[tickIndex]
            topTick:setPosition(x - tw * 0.5, bandTopY - th + curve)
            topTick:setDimension(tw, th)
            topTick:setRotation(0, 0, 0)
            topTick:setColor(0.95, 0.97, 0.98, 0.96)
            topTick:render()
            tickIndex = tickIndex + 1

            local bottomTick = self.tickOverlays[tickIndex]
            bottomTick:setPosition(x - tw * 0.5, bandBottomY + curve)
            bottomTick:setDimension(tw, th)
            bottomTick:setRotation(0, 0, 0)
            bottomTick:setColor(0.95, 0.97, 0.98, 0.96)
            bottomTick:render()
            tickIndex = tickIndex + 1

            if major or mid then
                local rounded = math.floor(wrapped + 0.5) % 360
                local absT = math.abs(t)
                local textArc = self.hudH * 0.012 * absT * absT
                local degreeY = self.centerY - self.hudH * 0.032 + textArc * 0.65
                setTextColor(0.97, 0.98, 1.0, 1)

                if major then
                    -- Keep the existing 45-degree cardinal display unchanged.
                    local card = cardinalFor(rounded)
                    local cardY = self.centerY + self.hudH * 0.015 + textArc
                    renderText(x, cardY, textSizeCardinal, card)
                    renderText(x, degreeY, textSizeDegree, tostring(rounded))
                else
                    -- Additional compass value every 15 degrees between the cardinals.
                    renderText(x, degreeY, textSizeDegree * 0.90, tostring(rounded))
                end
            end
        end
        mark = mark + 5
    end

end


function FS25_3D_Lagekompass:drawHUD()
    if self.hudEnabled == false then return end
    if self.vehicle == nil then return end
    if g_currentMission == nil or g_currentMission.hud == nil then return end
    if (self.hudVisibilityMode or 1) == 1 and g_currentMission.hud.isVisible == false then return end
    if not self:ensureHud() then return end

    -- Keep static image overlays synchronized with the live HUD position.
    -- The generated scales already use centerX/centerY each frame; only
    -- forgot to move the sphere overlay itself while dragging.
    self.sphereOverlay:setPosition(self.hudX, self.hudY)
    self.sphereOverlay:setDimension(self.hudW, self.hudH)
    self.sphereOverlay:render()

    local outerFactor = self.outerScaleFactor or 1.10
    local outerW = self.hudW * outerFactor
    local outerH = self.hudH * outerFactor
    self.outerScaleOverlay:setPosition(self.centerX - outerW * 0.5, self.centerY - outerH * 0.5)
    self.outerScaleOverlay:setDimension(outerW, outerH)
    self.outerScaleOverlay:setRotation(0, 0, 0)
    self.outerScaleOverlay:setColor(1, 1, 1, 1)
    self.outerScaleOverlay:render()

    self:drawOuterScale()
    self:drawPitchScale()
    self:drawPitchMarkers()
    self:drawRollIndicator()
    self:drawCompassCenterLine()
    self:drawCompassTape()
    self:drawPositionEditHint()

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextVerticalAlignment(RenderText.VERTICAL_ALIGN_BASELINE)
    setTextBold(false)
    setTextColor(1, 1, 1, 1)
end

function FS25_3D_Lagekompass:setControlledVehicle(vehicle)
    self.vehicle = vehicle
    self.lastVehicle = nil

    if vehicle ~= nil and vehicle.rootNode ~= nil then
        local heading = headingFromVehicle(vehicle)
        local pitch, roll = attitudeFromVehicle(vehicle)
        if heading ~= nil then self.heading = heading end
        if pitch ~= nil then self.pitch = pitch end
        if roll ~= nil then self.roll = roll end
        print(string.format("[%s] HUD vehicle set: %s", modName, tostring(vehicle.typeName or vehicle.typeDesc or vehicle)))
    end
end

function FS25_3D_Lagekompass:onMissionLoaded(mission)
    if mission == nil or mission.hud == nil then
        print("[" .. modName .. "] ERROR: mission HUD unavailable")
        return
    end

    self.mission = mission
    self:ensureHud()

    if not self.settingsHookInstalled and InGameMenuSettingsFrame ~= nil and InGameMenuSettingsFrame.onFrameOpen ~= nil then
        InGameMenuSettingsFrame.onFrameOpen = Utils.appendedFunction(InGameMenuSettingsFrame.onFrameOpen,
            function(frame)
                FS25_3D_Lagekompass:injectSettingsUi(frame)
            end)
        self.settingsHookInstalled = true
    end

    if not self.mouseHookInstalled then
        self.previousMouseEvent = mission.mouseEvent
        mission.mouseEvent = function(missionObject, posX, posY, isDown, isUp, button)
            if FS25_3D_Lagekompass:mouseEvent(posX, posY, isDown, isUp, button) then
                return true
            end
            if FS25_3D_Lagekompass.previousMouseEvent ~= nil then
                return FS25_3D_Lagekompass.previousMouseEvent(missionObject, posX, posY, isDown, isUp, button)
            end
        end
        self.mouseHookInstalled = true
    end

    if not self.hudHooksInstalled then
        mission.hud.setControlledVehicle = Utils.appendedFunction(mission.hud.setControlledVehicle,
            function(hud, vehicle)
                FS25_3D_Lagekompass:setControlledVehicle(vehicle)
            end)

        mission.hud.drawControlledEntityHUD = Utils.appendedFunction(mission.hud.drawControlledEntityHUD,
            function(hud)
                if hud.isVisible ~= false then
                    FS25_3D_Lagekompass:drawHUD()
                end
            end)

        self.hudHooksInstalled = true
        print("[" .. modName .. "] HUD hooks installed")
    end
end

function FS25_3D_Lagekompass:draw()
    -- In "Always visible" mode, draw independently when the normal GIANTS HUD
    -- has been hidden. When the normal HUD is visible, drawControlledEntityHUD
    -- remains the single render path, preventing duplicate rendering.
    if self.hudEnabled == false then return end
    if (self.hudVisibilityMode or 1) ~= 2 then return end
    if g_currentMission == nil or g_currentMission.hud == nil then return end
    if g_currentMission.hud.isVisible ~= false then return end

    self:drawHUD()
end

local function LagekompassMissionFinished(mission)
    FS25_3D_Lagekompass:onMissionLoaded(mission)
end

if Mission00 ~= nil and Mission00.loadMission00Finished ~= nil then
    Mission00.loadMission00Finished = Utils.appendedFunction(Mission00.loadMission00Finished, LagekompassMissionFinished)
end

addModEventListener(FS25_3D_Lagekompass)
