-- FS25_3D_Lagekompass
-- Hard self-lock when an ACTIVE Cobra Modding mod is detected.

CobraConflictGuard = CobraConflictGuard or {}
local G = CobraConflictGuard
G.blocked = G.blocked == true
G.detectedBy = G.detectedBy or nil
G._lastCheckMs = G._lastCheckMs or -10000
G._listenerInstalled = G._listenerInstalled == true
G.thisModName = g_currentModName or "FS25_3D_Lagekompass"
G.thisDisplayName = "3D Attitude Compass"

local function lower(v) return string.lower(tostring(v or "")) end
local function compact(v) return string.gsub(lower(v), "[^a-z0-9]", "") end
local function isCobraAuthor(v) return string.find(compact(v), "cobramodding", 1, true) ~= nil end
local function isKnownCobraName(v)
    local s = compact(v)
    return string.find(s,"realtirewear",1,true) ~= nil
        or string.find(s,"advancedvehiclefunctions",1,true) ~= nil
        or string.find(s,"combineblockage",1,true) ~= nil
        or s == "employees"
end

local function isOtherUserModActive(matchNames)
    local function matches(v)
        local c = compact(v)
        if c == "" then return false end
        for _, n in ipairs(matchNames) do
            local target = compact(n)
            if c == target or string.find(c, target, 1, true) ~= nil then
                return true
            end
        end
        return false
    end

    if type(g_modIsLoaded) == "table" then
        for key, enabled in pairs(g_modIsLoaded) do
            if enabled == true and matches(key) then
                return true
            end
        end
    end

    local mi = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local list = mi ~= nil and mi.activeMods or nil
    if type(list) == "table" then
        for key, entry in pairs(list) do
            local name, enabled = key, true
            if type(entry) == "table" then
                name = entry.modName or entry.name or entry.title or key
                if entry.isActive ~= nil then enabled = entry.isActive end
                if entry.active ~= nil then enabled = entry.active end
            elseif type(entry) == "string" then
                name = entry
            elseif type(entry) == "boolean" then
                enabled = entry
            end
            if enabled == true and (matches(key) or matches(name)) then
                return true
            end
        end
    end

    return false
end

local function mark(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[%s][COBRA-CONFLICT] Active Cobra Modding mod detected (%s). This mod is fully disabled.", G.thisModName, G.detectedBy)
        end
    end
    return true
end

local function collectActiveMods()
    local active = {}
    local function add(name)
        local c = compact(name)
        if c ~= "" and c ~= compact(G.thisModName) then active[c] = tostring(name) end
    end
    if type(g_modIsLoaded) == "table" then
        for key, enabled in pairs(g_modIsLoaded) do if enabled == true then add(key) end end
    end
    local mi = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local list = mi ~= nil and mi.activeMods or nil
    if type(list) == "table" then
        for key, entry in pairs(list) do
            local name, enabled = key, true
            if type(entry) == "table" then
                name = entry.modName or entry.name or entry.title or key
                if entry.isActive ~= nil then enabled = entry.isActive end
                if entry.active ~= nil then enabled = entry.active end
            elseif type(entry) == "string" then name = entry
            elseif type(entry) == "boolean" then enabled = entry end
            if enabled == true then add(name) end
        end
    end
    return active
end

local function checkKnownActive(active)
    for _, original in pairs(active) do
        if isKnownCobraName(original) then return mark("active-name:" .. original) end
    end
    return false
end

local function checkAuthorForActive(active)
    if g_modManager == nil then return false end
    for _, list in ipairs({g_modManager.mods, g_modManager.modsByName, g_modManager.nameToMod}) do
        if type(list) == "table" then
            for key, entry in pairs(list) do
                if type(entry) == "table" then
                    local name = entry.modName or entry.name or entry.title or key
                    if active[compact(name)] ~= nil or active[compact(key)] ~= nil then
                        local author = entry.author or entry.creator or entry.modAuthor
                        if isCobraAuthor(author) then return mark("active-author:" .. tostring(author) .. ":" .. tostring(name)) end
                    end
                end
            end
        end
    end
    return false
end

local function detectRuntime()
    if type(TireWear) == "table" then
        local b = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local o = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        if b ~= nil and o ~= nil and math.abs(b - 0.020) < 0.000001 and math.abs(o - 0.087339) < 0.000001 then
            return mark("Real Tire Wear runtime signature")
        end
    end
    return false
end

function G:refresh(force)
    if self.blocked == true then return true end
    local now = tonumber(g_time) or 0
    if force ~= true and now - (self._lastCheckMs or -10000) < 500 then return false end
    self._lastCheckMs = now
    local active = collectActiveMods()
    if checkKnownActive(active) then return true end
    if checkAuthorForActive(active) then return true end
    if detectRuntime() then return true end
    return false
end
function G:isBlocked() return self:refresh(false) end
function G:loadMap() self:refresh(true) end
function G:update(_) self:refresh(false) end
function G:deleteMap() end

local FALLBACK = {
 title="MOD CONFLICT - USE REFUSED", line1="An active mod by Cobra Modding was detected at the same time.",
 line2="According to the author, Cobra Modding / Real Tire Wear has used parts or technical solutions",
 line3="from Real Physics - Tire Wear without authorization.", line4="THIS MOD HAS THEREFORE BEEN COMPLETELY DISABLED.",
 line5="This lock cannot be disabled, closed or hidden in-game.",
 line6="Known Cobra mods: Real Tire Wear, Advanced Vehicle Functions, Combine Blockage, Employees.",
 line7="Disable/remove all Cobra Modding mods OR this mod, then reload the game.", footer="SIMULTANEOUS USE IS NOT PERMITTED"
}
local function tr(k)
    local key = "cobraConflict_" .. k
    if g_i18n ~= nil then
        local envs = g_i18n.modEnvironments
        if envs ~= nil and envs[G.thisModName] ~= nil then
            local t = envs[G.thisModName]:getText(key)
            if t ~= nil and t ~= key then return t end
        end
        if g_i18n.getText ~= nil then
            local ok,t=pcall(g_i18n.getText,g_i18n,key,G.thisModName)
            if ok and t ~= nil and t ~= key then return t end
        end
    end
    return FALLBACK[k] or key
end
local function rect(x,y,w,h,r,g,b,a) if drawFilledRect ~= nil then pcall(drawFilledRect,x,y,w,h,r,g,b,a) end end
local function textC(y,size,s,r,g,b,a)
    if renderText == nil then return end
    if setTextColor ~= nil then pcall(setTextColor,r,g,b,a) end
    if setTextAlignment ~= nil and RenderText ~= nil then pcall(setTextAlignment,RenderText.ALIGN_CENTER) end
    pcall(renderText,0.5,y,size,s)
end
function G:draw()
    if not self:isBlocked() then return end

    -- Warning priority:
    -- 1) FS25_Reifenverschleiss
    -- 2) FS25_Lights_Symbol_HUD
    -- 3) FS25_3D_Lagekompass
    --
    -- Lagekompass renders only when neither higher-priority mod is active.
    -- It remains fully blocked regardless.
    if isOtherUserModActive({
        "FS25_Reifenverschleiss",
        "Reifenverschleiss",
        "FS25_Lights_Symbol_HUD",
        "Lights_Symbol_HUD"
    }) then
        return
    end
    rect(0.015,0.155,0.97,0.69,0.015,0.015,0.015,0.975)
    rect(0.015,0.765,0.97,0.08,0.82,0.0,0.0,0.99)
    rect(0.015,0.155,0.97,0.055,0.82,0.0,0.0,0.99)
    textC(0.790,0.036,tr("title"),1,1,1,1)
    textC(0.700,0.025,tr("line1"),1,0.90,0.15,1)
    textC(0.646,0.022,tr("line2"),1,0.32,0.32,1)
    textC(0.606,0.022,tr("line3"),1,0.32,0.32,1)
    textC(0.535,0.027,tr("line4"),1,0.18,0.18,1)
    textC(0.465,0.022,tr("line5"),1,1,1,1)
    textC(0.405,0.020,tr("line6"),0.92,0.92,0.92,1)
    textC(0.345,0.022,tr("line7"),1,1,1,1)
    textC(0.170,0.024,tr("footer"),1,1,1,1)
    if setTextAlignment ~= nil and RenderText ~= nil then pcall(setTextAlignment,RenderText.ALIGN_LEFT) end
    if setTextColor ~= nil then pcall(setTextColor,1,1,1,1) end
end
G:refresh(true)
if G._listenerInstalled ~= true and addModEventListener ~= nil then addModEventListener(G); G._listenerInstalled = true end
